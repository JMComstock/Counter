from django.shortcuts import render, redirect

def index(request):
    if 'num_visits' in request.session:
        request.session['num_visits'] += 1
    else:
        request.session['num_visits'] = 1
    return render(request, "index.html")

def destroy(request):
    # request.session.clear()
    del request.session['num_visits']
    return redirect("/")

def plustwo(request):
    if 'num_visits' in request.session:
        request.session['num_visits'] += 1
    else:
        request.session['num_visits'] = 0
    return redirect("/")